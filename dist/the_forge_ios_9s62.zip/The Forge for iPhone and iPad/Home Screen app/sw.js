/*
   THE FORGE  |  Copyright (c) 2026 Yannie D. Forest. All rights reserved.
   NO LICENCE IS GRANTED. No copying, adaptation, redistribution, reverse
   engineering or commercial use without the author's written permission.
   See LICENCE.txt. Every distributed copy carries a build marker.

   The offline keeper for the Home Screen app. On the first visit it stores
   every file below on the device; after that the app opens with no
   connection at all. Every file named here MUST exist beside this one: if a
   single one is missing, the browser stores nothing and the app will not open
   offline. Change the CACHE name whenever index.html is replaced, so the new
   build is stored in place of the old one.
*/
const CACHE = "the-forge-home-v630";
// this keeper's own name without its build number: only stores that begin
// with it are this keeper's older versions
const OWN = CACHE.replace(/v\d+$/, "");
const ASSETS = [
  "./", "./index.html", "./manifest.webmanifest", "./favicon.ico",
  "./LICENCE.txt", "./TERMS.md", "./robots.txt",
  "./icons/apple-touch-icon.png", "./icons/icon-192.png", "./icons/icon-256.png",
  "./icons/icon-384.png", "./icons/icon-512.png", "./icons/icon-512-maskable.png"
];
self.addEventListener("install", e => {
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(ASSETS)).then(() => self.skipWaiting()));
});
self.addEventListener("activate", e => {
  // Only this keeper's own older stores are cleared. An app may keep large
  // downloads in stores of its own; clearing every other store would throw
  // them away each time a new build arrives.
  e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k.indexOf(OWN) === 0 && k !== CACHE).map(k => caches.delete(k)))).then(() => self.clients.claim()));
});
self.addEventListener("fetch", e => {
  if (e.request.method !== "GET") return;
  const req = e.request;
  // Requests to other sites pass straight through: whatever fetched them
  // keeps its own copy, so a second one here would only double the space used.
  if (new URL(req.url).origin !== self.location.origin) return;
  const isDoc = req.mode === "navigate" || req.destination === "document" || /index\.html$|\/$/.test(req.url);
  if (isDoc) {
    // Network-first for the app page, so a new build loads as soon as it is reachable; fall back to cache when offline.
    e.respondWith(
      fetch(req).then(resp => {
        try { if (resp && resp.ok) { const cp = resp.clone(); caches.open(CACHE).then(c => c.put(req, cp)); } } catch (_) {}
        return resp;
      }).catch(() => caches.match(req, { ignoreSearch: true }).then(r => r || caches.match("./index.html")))
    );
  } else {
    // Cache-first for static icons and assets.
    e.respondWith(
      caches.match(req).then(r => r || fetch(req).then(resp => {
        try { if (resp && resp.ok) { const cp = resp.clone(); caches.open(CACHE).then(c => c.put(req, cp)); } } catch (_) {}
        return resp;
      }))
    );
  }
});
