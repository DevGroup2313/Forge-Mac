#!/bin/zsh
# THE FORGE  |  Copyright (c) 2026 Yannie D. Forest. All rights reserved.
# NO LICENCE IS GRANTED. See LICENCE.txt.
#
# The Forge for iPhone and iPad, WAY 1: double-click this file on a Mac.
# It checks that Xcode is installed, opens the project in Xcode and shows the
# steps. Choosing your Apple ID to sign the app is the one part a script
# cannot do for you. Made from the file that opens Carpe Diem's iPhone and
# iPad project.
#
# It changes nothing on this Mac. It only looks for Xcode and opens the
# project with it. (The Forge marks this file as a program when it makes the
# zip, because its name ends in .command.)

cd "$(dirname "$0")" || exit 1
PROJ="iPhone and iPad project/iphone-ipad/TheForge.xcodeproj"

echo "==============================================="
echo "  The Forge for iPhone and iPad"
echo "==============================================="
echo

# Xcode itself, not only Apple's command line tools, which have no Run button.
has_xcode() {
  [ -d "/Applications/Xcode.app" ] && return 0
  case "$(xcode-select -p 2>/dev/null)" in
    *.app/Contents/Developer) return 0 ;;
  esac
  [ -n "$(mdfind "kMDItemCFBundleIdentifier == 'com.apple.dt.Xcode'" 2>/dev/null | head -n 1)" ] && return 0
  return 1
}

if [ ! -d "$PROJ" ]; then
  echo "The project is not beside this file. It should be here:"
  echo "  $PROJ"
  echo
  cat <<'EOF'
Unzip the whole package first. Then double-click this file inside the
folder "The Forge for iPhone and iPad", with the folder
"iPhone and iPad project" beside it.
EOF
  exit 1
fi

if ! has_xcode; then
  cat <<'EOF'
Xcode is not installed on this Mac yet.

  1. Open the App Store, search for Xcode and press Get. It is free and
     very large, so the download can take a long while.
  2. Open Xcode once and let it finish setting itself up. If it asks
     which platforms to add, choose iOS.
  3. Then double-click this file again.

READ ME FIRST.txt, Part 1, has every step.
EOF
  exit 1
fi

echo "Opening TheForge.xcodeproj in Xcode."
if ! open -b com.apple.dt.Xcode "$PROJ" 2>/dev/null && ! open "$PROJ"; then
  echo
  echo "Xcode did not open the project. Open Xcode yourself, choose File, then"
  echo "Open, and choose this:"
  echo "  $PROJ"
  exit 1
fi

cat <<'EOF'

If Xcode asks whether you trust a project that came from the internet,
choose to open it. Then three steps in Xcode:

  1. YOUR TEAM. In the column on the left, click TheForge at the very
     top (it has a blue icon). Under TARGETS click TheForge, then the
     tab "Signing & Capabilities". Leave "Automatically manage signing"
     ticked, and choose your name with "(Personal Team)" as the Team.
     (A "Set Up Signing" button instead? Click it and choose your Team.)
     No name to choose? Xcode, Settings, Accounts (or Apple Accounts),
     the + button: add your Apple ID, then choose the Team again.
     Leave the Bundle Identifier as it is: com.yannieforest.theforge

  2. YOUR DEVICE. Connect the iPhone or iPad with its cable and unlock it.
     If it asks whether to trust this computer, tap Trust. Then choose it
     at the top of the Xcode window. Not in the list? Choose Manage
     Devices there, click your device, and click Pair if it shows.
     The first time, wait while Xcode gets it ready.

  3. RUN. Press the Run button (the triangle), or Command + R.
     If a Register button shows under Signing, click it and Run again.

The first time only, Xcode may stop once or twice. That is expected:
  - If it says the device needs Developer Mode: on the device, Settings,
    Privacy & Security, Developer Mode: switch it on, tap Restart, unlock
    the device, then tap Enable and type your passcode. Press Run again.
  - If it then says it could not open the app: on the device, Settings,
    General, VPN & Device Management: under Developer App tap your Apple
    ID, then Trust. Be online while you do this. Press Run again.

With a free Apple ID the app lasts 7 days. Then connect the device, open
the project the same way and press Run again. Your work should stay;
export a backup from the app first, to be safe.

If it does not install: READ ME FIRST.txt, "IF IT DOES NOT INSTALL".
EOF
